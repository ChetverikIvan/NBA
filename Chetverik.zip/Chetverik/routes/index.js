var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});




router.get('/admin', function(req, res, next) {
  res.render('admin', { title: 'Admin Login' });
});




router.get('/visitors', function(req, res, next) {
  res.render('visitors', { title: 'Visitor menu' });
});

router.get('/Teams', function(req, res, next) {
  res.render('Teams', { title: 'Teams' });
});

router.get('/detail', function(req, res, next) {
  res.render('detail', { title: 'Team detail' });
});

module.exports = router;
